setwd("C:\\Users\\IT24102806\\Desktop\\IT24102806 Lab 4")
##Part 1
##Importing the data set
data<-read.table("DATA 4.txt", header = TRUE, sep = " ")
##Importing the data set
data<-read.table("Exercise.txt", header = TRUE, sep = " ")

0# View the file in a separate window


fix(data)
# Attach the file into R, so you can call the variables by their names
attach(data)

## Part 2
## Part (a)
# Obtaining Box Plots
boxplot(X1, main="Box plot for Team Attendence", outline=TRUE, outpch=8, horizontal=TRUE)
boxplot(X2, main="Box plot for Team Salary", outline=TRUE, outpch=8, horizontal=TRUE)
boxplot(X3, main="Box plot for Years", outline=TRUE, outpch=8, horizontal=TRUE)


# Obtaining Histogram
hist(X1, ylab="Frequency", xlab="Team Attendence", main="Histogram for Team Attendence")
hist(X2, ylab="Frequency", xlab="Team Salary", main="Histogram for Team Salary")
hist(X3, ylab="Frequency", xlab="Years", main="Histogram for Years")

